var express = require('express');
var router = express.Router();
const { MongoClient } = require('mongodb');


/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

const url = "mongodb://127.0.0.1:27017/";
const dbName = "Car";
const collectionName = "Cars";

router.get('/saveCar',async function(req,res){
  let car = {
    name: req.query.name,
    model: req.query.model,
    speed: req.query.speed,
    role: req.query.role,
    item: req.query.item,
  };
  const client = new MongoClient(url);
  await client.connect();
  let db = client.db(dbName);
  let collection = db.collection(collectionName);
  await collection.insertOne(car);
  res.render('index', { title: 'Данные успешно сохраненны' })
}); 

router.get('/getAllCar',async function(req,res){
  const client = new MongoClient(url);
  await client.connect();
  let db = client.db(dbName);
  let collection = db.collection(collectionName);
  let car = await collection.find({}).toArray();
  res.render('getCar', { car: car });

})

module.exports = router;
